![logo](http://phoenix.incubator.apache.org/images/logo.png)

<b>[Apache Phoenix](http://phoenix.incubator.apache.org/)</b> is a SQL skin over HBase delivered as a client-embedded JDBC driver targeting low latency queries over HBase data. Visit the Apache Phoenix Incubator website <b>[here](http://phoenix.incubator.apache.org/)</b>.

Copyright ©2014 [Apache Software Foundation](http://www.apache.org/). All Rights Reserved.
